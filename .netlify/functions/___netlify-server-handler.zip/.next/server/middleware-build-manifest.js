globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/03~yq9q893hmn.js"
  ],
  "lowPriorityFiles": [
    "static/Kv6WQwP9PciufqDWL9SU2/_buildManifest.js",
    "static/Kv6WQwP9PciufqDWL9SU2/_ssgManifest.js",
    "static/Kv6WQwP9PciufqDWL9SU2/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/0ht900cau6_ur.js",
    "static/chunks/03cnjj9mnzy_p.js",
    "static/chunks/07lhk_q6pmm3r.js",
    "static/chunks/turbopack-0bxcrz71-nfi1.js"
  ]
};
