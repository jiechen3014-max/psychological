globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/03~yq9q893hmn.js"
  ],
  "lowPriorityFiles": [
    "static/nI8ubyfLQz_QnvLLXj5V_/_buildManifest.js",
    "static/nI8ubyfLQz_QnvLLXj5V_/_ssgManifest.js",
    "static/nI8ubyfLQz_QnvLLXj5V_/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/0ht900cau6_ur.js",
    "static/chunks/03cnjj9mnzy_p.js",
    "static/chunks/07lhk_q6pmm3r.js",
    "static/chunks/turbopack-0bxcrz71-nfi1.js"
  ]
};
